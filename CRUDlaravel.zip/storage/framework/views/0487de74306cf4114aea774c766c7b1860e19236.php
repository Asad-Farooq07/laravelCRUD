<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
    <title>CRUD Eleqont ORM</title>
</head>
<body>

        <div class="container">
            <div class="row">
                <div class="sm-col6">
                    <form action="" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="name" class="form-label">
                                Name
                            </label>
                            <input type="text" class="form-control" id="name" name="name">
                        </div>
                        
                        <div class="mb-3">
                            <label for="city" class="form-label">
                                city
                            </label>
                            <input type="text" class="form-control" id="city" name="city">
                        </div>

                        <div class="mb-3">
                            <label for="marks" class="form-label">
                                marks
                            </label>
                            <input type="text" class="form-control" id="marks" name="marks">
                        </div>
                        <button type="submit" class="btn-btn-primary">submit</button>
                    </form> 
                    <?php if(session()->has('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="sm-col6">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th scope="col">id</th>
                                <th scope="col">name</th>
                                <th scope="col">city</th>
                                <th scope="col">marks</th>
                            </tr>
                        </thead>

                            <tbody>
                                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th><?php echo e($stu->id); ?></th>
                                    <td><?php echo e($stu->name); ?></td>
                                    <td><?php echo e($stu->city); ?></td>
                                    <td><?php echo e($stu->marks); ?></td>
                                    <td>
                                        <a href="<?php echo e(url('/edit',$stu->id)); ?>" class="btn btn-info btn-sm">Edit</a>
                                        <a href="<?php echo e(url('/delete',$stu->id)); ?>" class="btn btn-danger btn-sm">Delete</a>

                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                    </table>

                </div>
            </div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" 
        integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" 
        crossorigin="anonymous"></script>

</body>
</html><?php /**PATH E:\laravel playground\ms\crud1\resources\views/home.blade.php ENDPATH**/ ?>